Budowanie (potrzebna Java 21 + Gradle):
  gradle build
Gotowy plik: build/libs/AnyEnchant.jar -> wrzuc do plugins/ serwera Paper.

Bez instalowania czegokolwiek: wrzuc ten folder na GitHub (nowe repo),
wejdz w zakladke Actions -> Build -> Artifacts -> pobierz AnyEnchant.jar.

Dla wersji 26.x zmien wersje paper-api w build.gradle.kts na ta z docs.papermc.io.

Uzycie w grze:
  /ench <enchant> [poziom]   - enchant na przedmiocie w rece (bez poziomu = max)
  /ench all                  - wszystkie enchanty (bez klatw) na max
  /ench clear                - usuwa enchanty
Kowadlo: ksiazka z enchantem laczy sie z dowolnym przedmiotem.
Loyalty/Channeling na dowolnym przedmiocie (np. miecz): PPM = rzut.
