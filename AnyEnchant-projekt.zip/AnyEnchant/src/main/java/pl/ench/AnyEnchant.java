package pl.ench;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Player;
import org.bukkit.entity.Trident;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.EnchantmentStorageMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AnyEnchant extends JavaPlugin implements Listener, TabExecutor {

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("ench").setExecutor(this);
        getCommand("ench").setTabCompleter(this);
    }

    // ---------- helpers ----------

    private static Enchantment ench(String key) {
        return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(key.toLowerCase(Locale.ROOT)));
    }

    private static int lvl(ItemStack it, String key) {
        if (it == null || it.getType() == Material.AIR) return 0;
        Enchantment e = ench(key);
        return e == null ? 0 : it.getEnchantmentLevel(e);
    }

    private static boolean isSpear(ItemStack it) {
        return it.getType().name().endsWith("_SPEAR");
    }

    // ---------- komenda ----------
    // /ench <enchant> [poziom]   | /ench all | /ench clear

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Tylko dla graczy."); return true; }
        if (a.length < 1) return false;
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType() == Material.AIR) { p.sendMessage("Trzymaj przedmiot w rece."); return true; }

        if (a[0].equalsIgnoreCase("all")) {
            for (Enchantment e : Registry.ENCHANTMENT) {
                // pomijamy klatwy, zeby nie psuc przedmiotu
                String k = e.getKey().getKey();
                if (k.equals("binding_curse") || k.equals("vanishing_curse")) continue;
                it.addUnsafeEnchantment(e, e.getMaxLevel());
            }
            p.sendMessage("Dodano wszystkie enchanty (bez klatw) na maksymalnym poziomie.");
            return true;
        }
        if (a[0].equalsIgnoreCase("clear")) {
            for (Enchantment e : new ArrayList<>(it.getEnchantments().keySet())) it.removeEnchantment(e);
            p.sendMessage("Usunieto enchanty.");
            return true;
        }

        Enchantment e = ench(a[0]);
        if (e == null) { p.sendMessage("Nieznany enchant: " + a[0]); return true; }
        int level = e.getMaxLevel();
        if (a.length >= 2) {
            try { level = Math.max(1, Math.min(255, Integer.parseInt(a[1]))); }
            catch (NumberFormatException ex) { p.sendMessage("Poziom musi byc liczba."); return true; }
        }
        it.addUnsafeEnchantment(e, level);
        p.sendMessage("Dodano " + a[0] + " " + level);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.add("all");
            out.add("clear");
            for (Enchantment e : Registry.ENCHANTMENT) out.add(e.getKey().getKey());
            out.removeIf(x -> !x.startsWith(a[0].toLowerCase(Locale.ROOT)));
        }
        return out;
    }

    // ---------- Riptide + Lunge na dowolnym przedmiocie (PPM) ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = false)
    public void onUse(PlayerInteractEvent ev) {
        if (ev.getHand() != EquipmentSlot.HAND) return;
        if (!ev.getAction().isRightClick()) return;
        Player p = ev.getPlayer();
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType() == Material.AIR) return;

        int riptide = lvl(it, "riptide");
        if (riptide > 0 && it.getType() != Material.TRIDENT
                && (p.isInWater() || p.getWorld().hasStorm() && p.getLocation().getBlock().getLightFromSky() > 0)
                && !p.hasCooldown(it)) {
            Vector dir = p.getLocation().getDirection().normalize()
                    .multiply(3.0 * (1 + riptide) / 4.0);
            if (p.isOnGround()) dir.setY(Math.max(dir.getY(), 0.4));
            p.setVelocity(dir);
            p.setFallDistance(0);
            p.setCooldown(it, 20);
            p.getWorld().playSound(p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, 1f, 1f);
            return;
        }

        int lunge = lvl(it, "lunge");
        if (lunge > 0 && !isSpear(it) && !p.hasCooldown(it) && p.getFoodLevel() > 6) {
            Vector dir = p.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() < 1.0E-4) return;
            dir.normalize().multiply(0.7 + 0.35 * lunge).setY(0.15);
            p.setVelocity(dir);
            p.setExhaustion(p.getExhaustion() + 4f * lunge);
            p.setCooldown(it, 30);
            return;
        }

        // Loyalty / Channeling na przedmiocie innym niz trojzab: rzut jako pocisk Trident
        if (it.getType() != Material.TRIDENT && lvl(it, "riptide") == 0
                && (lvl(it, "loyalty") > 0 || lvl(it, "channeling") > 0)) {
            throwItem(p, it);
            ev.setCancelled(true);
        }
    }

    private void throwItem(Player p, ItemStack it) {
        ItemStack carried = it.clone();
        carried.setAmount(1);
        Trident t = p.launchProjectile(Trident.class, p.getLocation().getDirection().multiply(2.5));
        if (!bindItem(t, carried)) {
            t.remove();
            p.sendMessage("Nie udalo sie rzucic (API serwera nie pozwala podmienic przedmiotu w pocisku).");
            return;
        }
        boolean creative = p.getGameMode() == GameMode.CREATIVE;
        t.setPickupStatus(creative ? AbstractArrow.PickupStatus.CREATIVE_ONLY : AbstractArrow.PickupStatus.ALLOWED);
        if (!creative) {
            if (it.getAmount() <= 1) p.getInventory().setItemInMainHand(null);
            else it.setAmount(it.getAmount() - 1);
        }
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_TRIDENT_THROW, 1f, 1f);
    }

    // Podmienia przedmiot niesiony przez Trident (refleksja = odporne na rozne wersje API).
    // Zwraca false, jesli sie nie udalo, zeby gracz nie stracil miecza.
    private static boolean bindItem(Trident t, ItemStack item) {
        boolean set = false;
        for (String m : new String[]{"setItemStack", "setItem"}) {
            try { Trident.class.getMethod(m, ItemStack.class).invoke(t, item); set = true; break; }
            catch (ReflectiveOperationException ignored) { }
        }
        try { Trident.class.getMethod("setWeapon", ItemStack.class).invoke(t, item); }
        catch (ReflectiveOperationException ignored) { }
        if (!set) return false;
        for (String m : new String[]{"getItemStack", "getItem"}) {
            try {
                Object r = Trident.class.getMethod(m).invoke(t);
                if (r instanceof ItemStack is) return is.getType() == item.getType();
            } catch (ReflectiveOperationException ignored) { }
        }
        return false;
    }

    // ---------- Wind Burst / Density / Breach na dowolnym przedmiocie ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent ev) {
        if (!(ev.getDamager() instanceof Player p)) return;
        ItemStack it = p.getInventory().getItemInMainHand();
        if (it.getType() == Material.AIR || it.getType() == Material.MACE) return; // maca dziala natywnie
        float fall = p.getFallDistance();
        if (fall < 1.5f || p.isGliding()) return;

        int density = lvl(it, "density");
        if (density > 0) ev.setDamage(ev.getDamage() + 0.5 * density * fall);

        int breach = lvl(it, "breach");
        if (breach > 0) ev.setDamage(ev.getDamage() * (1.0 + 0.15 * breach)); // przyblizenie ignorowania pancerza

        int wind = lvl(it, "wind_burst");
        if (wind > 0) {
            Vector v = p.getVelocity();
            p.setVelocity(new Vector(v.getX(), 1.2 + 0.25 * (wind - 1), v.getZ()));
            p.setFallDistance(0);
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 1f);
        }
    }

    // ---------- Kowadlo: ksiazki z enchantami na dowolny przedmiot ----------

    @EventHandler
    public void onAnvil(PrepareAnvilEvent ev) {
        ItemStack first = ev.getInventory().getItem(0);
        ItemStack second = ev.getInventory().getItem(1);
        if (first == null || second == null) return;
        if (first.getType() == Material.AIR || first.getType() == Material.ENCHANTED_BOOK) return;
        if (!(second.getItemMeta() instanceof EnchantmentStorageMeta meta)) return;

        ItemStack result = ev.getResult() != null ? ev.getResult().clone() : first.clone();
        int cost = 0;
        for (Map.Entry<Enchantment, Integer> en : meta.getStoredEnchants().entrySet()) {
            int cur = result.getEnchantmentLevel(en.getKey());
            int add = en.getValue();
            int nl = (cur == add) ? Math.min(255, cur + 1) : Math.max(cur, add);
            result.addUnsafeEnchantment(en.getKey(), nl);
            cost += nl;
        }
        ev.setResult(result);
        ev.getView().setRepairCost(Math.max(1, Math.min(39, cost)));
    }
}
